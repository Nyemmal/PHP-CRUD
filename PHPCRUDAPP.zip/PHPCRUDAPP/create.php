<?php include "includes/dbconnection.php"?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

	<title>PHP Crud</title>
</head>
<body>
	<div class="container mt-5"> 
		<h2>Add new task</h2>
		<form method="POST" action="">

			<div class="form-group">
				<label>Task Name</label>
				<input type="text" name="task_name" class="form-control" required>
			</div>

			<div class="form-group">
				<label>Description</label>
				<textarea name="task_description" class="form-control"></textarea>
			</div>

			<button type="submit" name="submit" class="btn btn-primary">Submit</button>
			<a href="index.php" class="btn btn-secondary">cancel</a>
			 
		</form>

</div>

<?php
    if (isset($_POST['submit'])) {
        $task_name = $_POST['task_name'];
        $task_description = $_POST['task_description'];

        $sql = "INSERT INTO tasks (task_name, task_description) VALUES ('$task_name', '$task_description')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Task added successfully.'); window.location.href='index.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    ?>


</body>
</html>