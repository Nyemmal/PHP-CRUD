<?php

 include "includes/dbconnection.php";

  if(isset($_GET['id'])) {
 	$task_id = $_GET['id'];

 	$sql = "SELECT * from tasks where id = $task_id";
 	$result = $conn->query($sql);

 	if ($result->num_rows ==1) {
 		$row = $result->fetch_assoc();
 		$task_name = $row['task_name'];
 		$description = $row['task_description'];
 	} else {
 		echo "Task not found.";
 		exit();
 	}

 	} else {
 	echo "invalide request.";
 	exit();
 }

 if (isset($_POST['delete'])) {

 	$sql = "DELETE from tasks where id = $task_id";

 	if($conn->query($sql)===TRUE) {
 		echo "<script> alert('Task deleted successfully');
 		window.location.href='index.php';</script> ";
 	} else {
 		echo "Error deleting task:".$conn->error;
 	}
 
 }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Task</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Delete Task</h2>
        <p>Are you sure you want to delete the task "<?php echo $task_name; ?>"?</p>
        <form method="post" action="">
            <input type="hidden" name="task_id" value="<?php echo $task_id; ?>">
            <button type="submit" name="delete" class="btn btn-danger">Delete</button>
            <a href="index.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
