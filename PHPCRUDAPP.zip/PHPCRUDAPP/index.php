<?php include "includes/dbconnection.php"?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PHP CRUD</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

</head>
<body>
	<div class="container mt-5">
		<h2>Task Manager</h2>
		<a href="create.php" class="btn btn-success mb-2"> Add Task</a>

		<table class="table table-striped">
			<thead>
				<tr>
					<th>ID</th>
					<th>Task name</th>
					<th>Description</th>
					<th>Created At</th>
					<th>Actions</th>
				</tr>
			</thead>

			<tbody>
				<?php 

				$sql = "SELECT *FROM tasks";
				$result = $conn->query($sql);

				if ($result->num_rows > 0) {
					while ($row = $result->fetch_assoc()) {

						echo "<tr>
							<td>".$row['id']."</td>
							<td>".$row['task_name']."</td>
							<td>".$row['task_description']."</td>
							<td>".$row['created_at']."</td>
							<td>
						<a href ='update.php?id=".$row['id']."' class = 'btn btn-info btn-sm'>Edit</a>
						<a href ='delete.php?id=".$row['id']."' class = 'btn btn-danger btn-sm'>Delete</a>

						</td>

						</tr>";


						// code...
					}

				} else {
					echo "<tr><td colspan = '5'> No tasks found</td></tr>";
				}

				?>

			</tbody>
		</table>		
	</div>

</body>
</html>