<?php
include "includes/dbconnection.php";

 if(isset($_GET['id'])) {
 	$task_id = $_GET['id'];

 	$sql = "SELECT * from tasks where id = $task_id";
 	$result = $conn->query($sql);

 	if ($result->num_rows ==1) {
 		$row = $result->fetch_assoc();
 		$task_name = $row['task_name'];
 		$description = $row['task_description'];
 	} else {
 		echo "Task not found.";
 		exit();
 	}
 } else {
 	echo "invalide request.";
 	exit();
 }

 if (isset($_POST['submit'])) {
 	$task_name = $_POST['task_name'];
 	$description = $_POST['task_description'];

 	$sql = "UPDATE tasks set task_name = '$task_name', task_description = '$description' where id = $task_id";

 	if($conn->query($sql)===TRUE) {
 		echo "<script> alert('Task updated successfully');
 		window.location.href='index.php';</script> ";
 	} else {
 		echo "Error updating task:".$conn->error;
 	}
 
 }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Task</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Task</h2>
        <form method="post" action="">
            <div class="form-group">
                <label>Task Name</label>
                <input type="text" name="task_name" class="form-control" value="<?php echo $task_name; ?>" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="task_description" class="form-control"><?php echo $description; ?></textarea>
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Update</button>
            <a href="index.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>


